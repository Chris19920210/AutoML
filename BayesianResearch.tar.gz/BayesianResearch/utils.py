from sklearn.datasets import load_svmlight_file
import numpy as np
import json
from skopt.space import Real, Integer, Categorical
import math


def get_data(path):
    data = load_svmlight_file(path)
    return data[0], data[1]


def logit_loss(y_test, y_pred):
    return np.array(list(map(lambda y_y_hat : -np.log(y_y_hat[1]) if y_y_hat[0] > 0 else -np.log(1.0 - y_y_hat[1]),
                             zip(y_test, y_pred)))).mean()


class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)


class RealGenerator:
    def __init__(self, real):
        self.low = real.low
        self.high = real.high

    def ask(self, n_points=1):
        return np.random.uniform(self.low, self.high, n_points)


class IntegerGenerator:
    def __init__(self, integer):
        self.low = integer.low
        self.high = integer.high

    def ask(self, n_points=1):
        return np.random.random_integers(self.low, self.high, n_points)


class CategoricalGenerator:
    def __init__(self, category):
        self.category = category.categories

    def ask(self, n_points=1):
        return np.random.choice(self.category, n_points)


class RandomGridSearch:
    def __init__(self, dimensions):
        self.dimensions = dimensions
        self.sampler = self.sampler_generator()
        self.explored = set()
        self.y = []

    def ask(self, n_points=1):
        params = []
        count = 0
        while count < n_points:
            param = list(map(lambda x: x.ask()[0], self.sampler))
            check = "".join((map(str, param)))
            if check not in self.explored:
                self.explored.add(check)
                params.append(param)
                count += 1
        return params

    def sampler_generator(self):
        sampler = []
        for each in self.dimensions:
            if isinstance(each, Real):
                sampler.append(RealGenerator(each))
            elif isinstance(each, Categorical):
                sampler.append(Categorical(each))
            elif isinstance(each, Integer):
                sampler.append(IntegerGenerator(each))
            else:
                raise TypeError
        return sampler

    def tell(self, y):
        if hasattr(y, '__iter__'):
            for i in range(len(y)):
                self.y.append(i)
        else:
            self.y.append(y)


class Arm:
    def __init__(self, alpha, mean):
        self.alpha = alpha
        self.r = 0
        self.exploration = 0
        self.mean = mean

    def upper(self):
        return self.mean + self.exploration

    def update(self, n, y):
        self.r += 1
        self.mean = (self.mean * self.r + y) / (self.r + 1)
        tao = math.ceil(math.pow(1 + self.alpha, self.r))
        self.exploration = math.sqrt((1 + self.alpha)*math.log(math.e*n/tao) / (2 * tao))

    def compare(self, arm):
        return self.upper() > arm.upper()




def main():
    num_leaves = Integer(20, 50)
    num_boost_round = Integer(100, 300)
    learning_rate = Real(0.1, 1)
    lambda_l1 = Real(0, 1)
    lambda_l2 = Real(0, 1)
    # Dimensions
    dimensions = [num_leaves, num_boost_round, learning_rate, lambda_l1, lambda_l2]
    opt = RandomGridSearch(dimensions)
    print(opt.ask())


if __name__ == '__main__':
    main()








